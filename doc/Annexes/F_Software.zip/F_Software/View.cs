﻿/******************************************************************************/
// Project		: User Retrival for 2126 Affichage Matriciel Nom Etudiant
// Author 		: Ricardo Crespo
// Date 		: 12.06.2022
// Descrition   : Fichier du code principale
/******************************************************************************/

// All used lebrarys
using System.Windows.Forms;
using UserRetrieval.Controllers;
using System.IO.Ports;
using System.Linq;
using System;

namespace UserRetrieval.Views
{
    /// <summary>
    /// User Interface Class
    /// </summary>
    public partial class View : Form
    {
        /// <summary>
        /// Property
        /// </summary>
        internal Controller Ctrler { get; set; }    // Contreuleru poru la classe Controller

        private const string KEY = "C";             // Clé de retour attendue
        private const string END_NAM_KEY = "XDR";   // Clé de fin de nom
        private const string ANNOUNCE_KEY = "x";    // Clé d'annoncement
        
        string[] ports = new string[] {" "};        // Tableu de travail des ports actuels
        string[] portsNew = new string[] {" "};     // Tableau avec les nouveaux ports
        string[] portsOld = new string[] {" "};     // Tableau avec les anciens ports
        
        string useName = "Default";                 // Utilisateur par défaut si pas trouvé

        int curentSelectedPort = 0;                 // Le port COM selectionné actuellement
        int counterTimerEndCom = 0;                 // Temps d'attente de réponse

        bool canRetryOpen = true;                   // Peut réessayer un communication
        bool canEndCom = false;                     // Peut mettre fin à une communicaiton

        /// <summary>
        /// Default constructor
        /// </summary>
        public View()
        {
            // Initialisation des components
            InitializeComponent();
            // Lecture des ports au démarage 
            canRetryOpen = RefreshSerialPort();
            // Configure les paramétres de la communicaiton UART
            InitSerialCom();
            // Démarre le timer1 principalle qui fait tourner tout le programme
            timer1.Start();
        }

        /// <summary>
        /// Sets the text to the text label
        /// </summary>
        /// <param name="userInfos"></param>
        internal void SetText(string userInfos)
        {
            // Récupération du nom de la séssion
            useName = userInfos;
            // Affiche le nom de l'éleve sur la fenetre
            this.lblUserName.Text = userInfos;
        }

        // Évenement si on reçoi des données via la communication UART sur un port COM
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            // Buffeur de lecture des données reçues
            string dataRx = serialPort1.ReadExisting();

            // Si les données reçues sont égales à la clé secrète
            if (dataRx == KEY)
            {
                // Reste avec le port COM ouvert
                canEndCom = false;
                // Reset le compteur d'attente de réponse
                counterTimerEndCom = 0;
                // Envoye le nom de la session
                SendMesageCom();
            }
        }

        // Envoi du nom de la session par UART via le port COM
        private void SendMesageCom()
        {
            // Récupération du prénom et de la première léttre du nom de la session
            string name = useName.Substring(0, useName.IndexOf(' ') + 2);
            // Ajoute une clé de fin de nom pour s'assurer le l'envoy complet à la réception
            name = name.Insert(name.Length, END_NAM_KEY);
            // Convertion de tous les potentiels accents en letres normales
            byte[] tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(name);
            // Envoie du nom de la session corectement encodé
            serialPort1.Write(System.Text.Encoding.UTF8.GetString(tempBytes));
            // Arrete la communication et ferme le port COM actuel
            EndTryCom();
        }

        // Récupéraiton les ports COM du system
        private bool RefreshSerialPort()
        {
            // Récupération de la listes des port COM du system
            portsNew = SerialPort.GetPortNames();

            // Si la nouvelle liste de ports COM est diférente de la prècedente
            if (!Enumerable.SequenceEqual(portsNew, portsOld))
            {
                // Redimentionnement du tableu des ports COM à la taille du nouveau tableau COM
                Array.Resize<string>(ref ports, portsNew.Length);
                // Copie du tableau des nouveaux ports dans le tableau des ports de travail
                portsNew.CopyTo(ports, 0);
                // Redimentionnement du tableu des anciens ports COM à la taille du tableau de travail COM
                Array.Resize<string>(ref portsOld, ports.Length);
                // Copie du tableau des ports de travail dans le tableu des anciens ports COM
                ports.CopyTo(portsOld, 0);
                // Retourner une réponse vrai
                return true;
            }
            // Si non on a la même liste de ports
            else
            {
                // Retourner une réponse fausse
                return false;
            }
        }

        // Initialisaiton des paramétres UART du port COM
        private void InitSerialCom()
        {
            // Configuration du BaudRate
            serialPort1.BaudRate = 9600;
            // Pas de parité
            serialPort1.Parity = Parity.None;
            // Taille du message de 8 bits
            serialPort1.DataBits = 8;
            // Un seul bit de stop
            serialPort1.StopBits = StopBits.One;
            // Pas de Handshake
            serialPort1.Handshake = Handshake.None;

            // Set read timeouts
            serialPort1.ReadTimeout = 500;
            // Set write timeouts
            serialPort1.WriteTimeout = 500;
        }

        // Essay d'ouvrir un port COM
        private bool TryOpenCom()
        {
            // Testes tous les ports COM du tableau de travail des ports COM
            for (int i = 0; i < ports.Length; i++)
            {
                // Essaye d'ouvri le port COM actuelle
                try
                {
                    // Récupération du nom du port COM actuel
                    serialPort1.PortName = (string)ports[i];
                    // Ouverture du port COM actuel
                    serialPort1.Open();
                    // Compteur du port COM selectionné actuellement
                    curentSelectedPort = i;
                    // Retourner une réponse vrai
                    return true;
                }
                // Si non s'il n'arrive pas
                catch
                {
                    // Passe à la prochainne action
                    continue;
                }
            }
            // Retourner une réponse fausse
            return false;
        }

        // Commence l'essay de communication avec tous les ports COM
        private void StartTryCom()
        {
            // Si on arrive à ouvri le port COM et qu'on a le droit d'en ouvrir un 
            if (TryOpenCom() && canRetryOpen)
            {
                // Essaye d'envoier la clé d'envoy pour s'annoncer au device voulu qui l'attend
                try
                {
                    // Envoi le la clé d'annonce sur le port COM ouvert actuellement
                    serialPort1.Write(ANNOUNCE_KEY);
                }
                // Si non s'il n'arrive pas continnue normalment l'execution du programme
                catch { }

                // Démare le délait d'attente de réception de la clé de retour sur le port COM actuel
                canEndCom = true;
                // Arrete d'essayer d'ouvir un autre port COM
                canRetryOpen = false;
            }
            // Si non on n'arrive pas à ouvrir les ports COM et on n'a pas le droit d'en ouvrir
            else
            {
                // Récupéraiton des ports COM du system
                canRetryOpen = RefreshSerialPort();
            }
        }

        // Fini la communicaiton avec le port COM actuel et le ferme
        private void EndTryCom()
        {
            // Ferme le port COM actuel
            serialPort1.Close();
            // Efface le port COM actuel de la liste de travail des ports COM
            ports[curentSelectedPort] = " ";
            // Arete la fermeture des ports et reprend le code normalment
            canEndCom = false;
            // Peut réessayer d'ouvrir un autre port
            canRetryOpen = true;
        }

        // Évenement du Timer1 toutes les 200ms
        private void timer1_Tick(object sender, System.EventArgs e)
        {
            // Si on peut commencer le délait d'attente de la réception de la clé
            if (canEndCom)
            {
                // Si on a attendu 2sec
                if (counterTimerEndCom == 10)
                {
                    // Fini la communicaiton avec le port COM actuel et le ferme
                    EndTryCom();
                    // Reset compteur d'attente de réponse
                    counterTimerEndCom = 0;
                }
                // Incrémentation du compteur d'attente de réponse
                counterTimerEndCom++;
            }
            // Si non on a pas une communication en cours et donc on peut essayer d'en commencer une
            else
            {
                // Commence l'essay de communication avec tous les ports COM
                StartTryCom();
            }
        }
    }
}
